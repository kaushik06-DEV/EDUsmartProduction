

import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { Course, BookRequest, CourseMaterial, TutorMessage, AdminInstruction, StudentProfile, AdminProfile, TutorProfile, Hackathon, HackathonRegistration, HackathonAnnouncement, HackathonResult, Task, Notification, LeaderboardEntry, Certificate, CertificateTemplate } from '../types';
import { useAuth } from './AuthContext';
import { api } from '../services/geminiService';
import { COURSES, STUDENT_PROFILES, DEFAULT_ADMIN_PROFILE, DEFAULT_TUTOR_PROFILE, HACKATHONS, SAMPLE_HACKATHON_REGISTRATIONS, LEADERBOARD_DATA, CERTIFICATE_TEMPLATES, getGeneratedStudentProfiles } from '../constants';


// Define the shape of the initial data payload from the backend.
interface InitialDataPayload {
  courses: Course[];
  bookRequests: BookRequest[];
  tutorMessages: TutorMessage[];
  adminInstructions: AdminInstruction[];
  studentProfiles: StudentProfile[];
  adminProfile: AdminProfile;
  tutorProfile: TutorProfile;
  hackathons: Hackathon[];
  hackathonRegistrations: HackathonRegistration[];
  tasks: Task[];
  notifications: Notification[];
  leaderboardData: LeaderboardEntry[];
  certificates: Certificate[];
  certificateTemplates: CertificateTemplate[];
}

interface DataContextType {
  loading: boolean;
  error: string | null;
  courses: Course[];
  bookRequests: BookRequest[];
  tutorMessages: TutorMessage[];
  adminInstructions: AdminInstruction[];
  studentProfiles: StudentProfile[];
  adminProfile: AdminProfile | null;
  tutorProfile: TutorProfile | null;
  hackathons: Hackathon[];
  hackathonRegistrations: HackathonRegistration[];
  tasks: Task[];
  notifications: Notification[];
  leaderboardData: LeaderboardEntry[];
  certificates: Certificate[];
  certificateTemplates: CertificateTemplate[];
  initializeDatabase: () => Promise<void>;
  clearDatabase: () => Promise<void>;
  getCourseById: (id: string) => Course | undefined;
  getHackathonById: (id: string) => Hackathon | undefined;
  getStudentProfileById: (id: string) => StudentProfile | undefined;
  addStudentProfile: (profile: StudentProfile) => Promise<void>;
  addCourse: (course: Omit<Course, 'id' | 'industryRelevance' | 'materials'>) => Promise<void>;
  deleteCourse: (courseId: string) => Promise<void>;
  addCourseMaterial: (courseId: string, material: Omit<CourseMaterial, 'id'>) => Promise<void>;
  addBookRequest: (request: Omit<BookRequest, 'id' | 'status'>) => Promise<void>;
  acceptBookRequest: (requestId: string) => Promise<void>;
  sendTutorMessage: (text: string) => Promise<void>;
  broadcastInstruction: (text: string) => Promise<void>;
  updateStudentProfile: (profile: StudentProfile) => Promise<void>;
  updateAdminProfile: (profile: AdminProfile) => Promise<void>;
  updateTutorProfile: (profile: TutorProfile) => Promise<void>;
  createHackathon: () => Promise<void>;
  updateHackathon: (details: Hackathon) => Promise<void>;
  deleteHackathon: (hackathonId: string) => Promise<void>;
  addHackathonAnnouncement: (hackathonId: string, announcementText: string) => Promise<void>;
  publishHackathonResults: (hackathonId: string, results: HackathonResult[]) => Promise<void>;
  registerForHackathon: (registration: Omit<HackathonRegistration, 'id' | 'timestamp'>) => Promise<void>;
  getRegistrationForStudent: (studentId: string, hackathonId: string) => HackathonRegistration | undefined;
  addTask: (text: string) => Promise<void>;
  updateTask: (task: Task) => Promise<void>;
  deleteTask: (taskId: string) => Promise<void>;
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  deleteNotification: (notificationId: string) => void;
  getCertificateById: (id: string) => Certificate | undefined;
  addCertificateTemplate: (template: Omit<CertificateTemplate, 'id'>) => Promise<void>;
  updateCertificateTemplate: (template: CertificateTemplate) => Promise<void>;
  deleteCertificateTemplate: (templateId: string) => Promise<void>;
  issueCertificate: (data: { templateId: string; studentId: string; courseName: string; }) => Promise<void>;
  // Fix: Add provideCertificate to fix compilation error in CreateCertificatePage.
  provideCertificate: (data: { studentId: string; certificateName: string; className: string; department: string; imageUrl: string; }) => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [courses, setCourses] = useState<Course[]>([]);
  const [bookRequests, setBookRequests] = useState<BookRequest[]>([]);
  const [tutorMessages, setTutorMessages] = useState<TutorMessage[]>([]);
  const [adminInstructions, setAdminInstructions] = useState<AdminInstruction[]>([]);
  const [studentProfiles, setStudentProfiles] = useState<StudentProfile[]>([]);
  const [adminProfile, setAdminProfile] = useState<AdminProfile | null>(null);
  const [tutorProfile, setTutorProfile] = useState<TutorProfile | null>(null);
  const [hackathons, setHackathons] = useState<Hackathon[]>([]);
  const [hackathonRegistrations, setHackathonRegistrations] = useState<HackathonRegistration[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [certificateTemplates, setCertificateTemplates] = useState<CertificateTemplate[]>([]);

  useEffect(() => {
    const fetchInitialData = () => {
      try {
        setLoading(true);
        setError(null);
        
        // Load static data
        setCourses(COURSES);
        setAdminProfile(DEFAULT_ADMIN_PROFILE);
        setTutorProfile(DEFAULT_TUTOR_PROFILE);
        setHackathons(HACKATHONS);
        setHackathonRegistrations(SAMPLE_HACKATHON_REGISTRATIONS);
        setLeaderboardData(LEADERBOARD_DATA);
        
        // Load data from localStorage to persist state
        const storedStudents = localStorage.getItem('studentProfiles');
        setStudentProfiles(storedStudents ? JSON.parse(storedStudents) : STUDENT_PROFILES);

        const storedNotifications = localStorage.getItem('notifications');
        setNotifications(storedNotifications ? JSON.parse(storedNotifications) : []);
        
        const storedCertificates = localStorage.getItem('certificates');
        setCertificates(storedCertificates ? JSON.parse(storedCertificates) : []);
        
        const storedCertTemplates = localStorage.getItem('certificateTemplates');
        setCertificateTemplates(storedCertTemplates ? JSON.parse(storedCertTemplates) : CERTIFICATE_TEMPLATES);
        
        // These are not persisted for simplicity in the demo
        setBookRequests([]);
        setTutorMessages([]);
        setAdminInstructions([]);
        setTasks([]);
        
      } catch (err: any) {
        setError(err.message || 'Failed to load application data.');
      } finally {
        setTimeout(() => setLoading(false), 200);
      }
    };

    fetchInitialData();
  }, []);

  useEffect(() => {
    try {
        localStorage.setItem('studentProfiles', JSON.stringify(studentProfiles));
    } catch (e) {
        console.error("Could not write student profiles to localStorage", e);
    }
  }, [studentProfiles]);

  useEffect(() => {
    try {
        localStorage.setItem('notifications', JSON.stringify(notifications));
        localStorage.setItem('certificates', JSON.stringify(certificates));
        localStorage.setItem('certificateTemplates', JSON.stringify(certificateTemplates));
    } catch (e) {
        console.error("Could not write to localStorage", e);
    }
  }, [notifications, certificates, certificateTemplates]);

  // --- Notification Functions ---
  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => {
    const newNotification: Notification = {
        ...notification,
        id: `notif-${Date.now()}`,
        timestamp: Date.now(),
        isRead: false
    };
    setNotifications(prev => [newNotification, ...prev].slice(0, 20)); 
  };

  const markNotificationAsRead = (notificationId: string) => {
    setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const deleteNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  const initializeDatabase = async () => {
    alert("Database simulation: Data has been reset to defaults.");
    const generatedProfiles = getGeneratedStudentProfiles();
    setStudentProfiles(generatedProfiles);
    localStorage.setItem('studentProfiles', JSON.stringify(generatedProfiles));
    // Reset other parts of the app state if needed
    window.location.reload();
  };

  const clearDatabase = async () => {
      if (window.confirm("WARNING: This will clear all application data, including registered students.")) {
          localStorage.removeItem('studentProfiles');
          localStorage.removeItem('notifications');
          localStorage.removeItem('certificates');
          localStorage.removeItem('certificateTemplates');
          localStorage.removeItem('hasSeenWelcomePage');
          localStorage.removeItem('eduSmartLanguage');
          window.location.reload();
      }
  };
  
  const getCourseById = (id: string) => courses.find(c => c.id === id);
  const getHackathonById = (id: string) => hackathons.find(h => h.id === id);
  const getStudentProfileById = (id: string) => studentProfiles.find(p => p.id === id);
  const getRegistrationForStudent = (studentId: string, hackathonId: string) => hackathonRegistrations.find(reg => reg.studentId === studentId && reg.hackathonId === hackathonId);
  const getCertificateById = (id: string) => certificates.find(c => c.id === id);

  const addStudentProfile = async (profile: StudentProfile) => {
    setStudentProfiles(prev => [...prev, profile]);
    addNotification({
        text: `New student registered: ${profile.name} (${profile.rollNumber})`,
        type: 'new_user',
        linkTo: `/students/${profile.id}`
    });
  };

  const addCourse = async (courseData: Omit<Course, 'id' | 'industryRelevance' | 'materials'>) => {
    const newCourse: Course = {
        ...courseData,
        id: `course-${Date.now()}`,
        industryRelevance: Math.floor(Math.random() * 21) + 80, // 80-100
        materials: []
    };
    setCourses(prev => [...prev, newCourse]);
  };

  const deleteCourse = async (courseId: string) => {
    setCourses(prev => prev.filter(c => c.id !== courseId));
  };
  
  const addCourseMaterial = async (courseId: string, materialData: Omit<CourseMaterial, 'id'>) => {
    const newMaterial: CourseMaterial = { ...materialData, id: `mat-${Date.now()}` };
    setCourses(prev => prev.map(c => c.id === courseId ? { ...c, materials: [...c.materials, newMaterial] } : c));
  };

  const addBookRequest = async (requestData: Omit<BookRequest, 'id' | 'status'>) => {
      const newRequest: BookRequest = { ...requestData, id: `br-${Date.now()}`, status: 'Pending' };
      setBookRequests(prev => [...prev, newRequest]);
  }

  const acceptBookRequest = async (requestId: string) => {
      let bookTitle = '';
      setBookRequests(prev => prev.map(req => {
          if (req.id === requestId) {
              bookTitle = req.bookTitle;
              return { ...req, status: 'Accepted' };
          }
          return req;
      }));
      if (bookTitle) {
          addNotification({
              text: `Your book request for "${bookTitle}" has been accepted.`,
              type: 'book',
              linkTo: '/request-book',
          });
      }
  }

  const sendTutorMessage = async (text: string) => {
    const newMessage: TutorMessage = { id: `tm-${Date.now()}`, text, timestamp: Date.now() };
    setTutorMessages(prev => [...prev, newMessage]);
  }

  const broadcastInstruction = async (text: string) => {
    const newInstruction: AdminInstruction = { id: `ai-${Date.now()}`, text, timestamp: Date.now() };
    setAdminInstructions(prev => [newInstruction, ...prev]);
    addNotification({
        text: `New Announcement: ${text.substring(0, 40)}...`,
        type: 'announcement',
        linkTo: '/',
    });
  }
  
  const updateStudentProfile = async (profile: StudentProfile) => {
      setStudentProfiles(prev => prev.map(p => p.id === profile.id ? profile : p));
  };

  const updateAdminProfile = async (profile: AdminProfile) => {
      setAdminProfile(profile);
  };

  const updateTutorProfile = async (profile: TutorProfile) => {
      setTutorProfile(profile);
  };

  const createHackathon = async () => {
    const newHackathon: Hackathon = {
      id: `hack-${Date.now()}`,
      title: 'New Hackathon Event',
      theme: 'To be determined',
      description: 'Details coming soon!',
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days from now
      rules: [], prizes: [], resources: [], announcements: [], results: []
    };
    setHackathons(prev => [...prev, newHackathon]);
  };

  const updateHackathon = async (details: Hackathon) => {
      setHackathons(prev => prev.map(h => h.id === details.id ? details : h));
  }

  const deleteHackathon = async (hackathonId: string) => {
    setHackathons(prev => prev.filter(h => h.id !== hackathonId));
  };

  const addHackathonAnnouncement = async (hackathonId: string, announcementText: string) => {
    const newAnnouncement: HackathonAnnouncement = { id: `ann-${Date.now()}`, text: announcementText, timestamp: Date.now() };
    setHackathons(prev => prev.map(h => h.id === hackathonId ? { ...h, announcements: [newAnnouncement, ...h.announcements] } : h));
  };

  const publishHackathonResults = async (hackathonId: string, results: HackathonResult[]) => {
      const resultsWithIds = results.map((r, i) => ({...r, id: `res-${Date.now()}-${i}`}));
      setHackathons(prev => prev.map(h => h.id === hackathonId ? { ...h, results: resultsWithIds } : h));
  };

  const registerForHackathon = async (registrationData: Omit<HackathonRegistration, 'id' | 'timestamp'>) => {
      const newRegistration: HackathonRegistration = { ...registrationData, id: `reg-${Date.now()}`, timestamp: Date.now() };
      setHackathonRegistrations(prev => [...prev, newRegistration]);
  };

  const addTask = async (text: string) => {
    const newTask: Task = { id: `task-${Date.now()}`, text, completed: false };
    setTasks(prev => [newTask, ...prev]);
    addNotification({
        text: `New task added: "${text}"`,
        type: 'task',
        linkTo: '/tasks',
    });
  };

  const updateTask = async (task: Task) => {
    setTasks(prev => prev.map(t => t.id === task.id ? task : t));
  };

  const deleteTask = async (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  // --- Certificate Functions ---
  const addCertificateTemplate = async (templateData: Omit<CertificateTemplate, 'id'>) => {
    const newTemplate: CertificateTemplate = { ...templateData, id: `template-${Date.now()}` };
    setCertificateTemplates(prev => [...prev, newTemplate]);
  };

  const updateCertificateTemplate = async (template: CertificateTemplate) => {
    setCertificateTemplates(prev => prev.map(t => t.id === template.id ? template : t));
  };

  const deleteCertificateTemplate = async (templateId: string) => {
    setCertificateTemplates(prev => prev.filter(t => t.id !== templateId));
  };

  const issueCertificate = async (data: { templateId: string; studentId: string; courseName: string; }) => {
    const template = certificateTemplates.find(t => t.id === data.templateId);
    const student = getStudentProfileById(data.studentId);
    const tutor = tutorProfile;

    if (!template || !student || !tutor) {
      throw new Error("Template, Student, or Tutor profile not found");
    }

    const newCertificate: Certificate = {
      id: `cert-${Date.now()}`,
      studentId: student.id,
      studentName: student.name,
      studentRollNumber: student.rollNumber,
      tutorId: tutor.id,
      tutorName: tutor.name,
      certificateName: template.title,
      className: data.courseName,
      department: template.issuingAuthority,
      imageUrl: template.imageUrl || 'https://images.unsplash.com/photo-1593341642344-802f0261aa84?q=80&w=1974&auto=format&fit=crop',
      issueDate: new Date().toISOString(),
    };
    
    setCertificates(prev => [...prev, newCertificate]);
    
    addNotification({
        text: `You have been awarded a new certificate: "${template.title}"!`,
        type: 'announcement',
        linkTo: `/certificates/${newCertificate.id}`,
    });
  };

  const provideCertificate = async (data: { studentId: string; certificateName: string; className: string; department: string; imageUrl: string; }) => {
    const student = getStudentProfileById(data.studentId);
    const tutor = tutorProfile;

    if (!student || !tutor) {
      throw new Error("Student or Tutor profile not found");
    }

    const newCertificate: Certificate = {
      id: `cert-${Date.now()}`,
      studentId: student.id,
      studentName: student.name,
      studentRollNumber: student.rollNumber,
      tutorId: tutor.id,
      tutorName: tutor.name,
      certificateName: data.certificateName,
      className: data.className,
      department: data.department,
      imageUrl: data.imageUrl,
      issueDate: new Date().toISOString(),
    };
    
    setCertificates(prev => [...prev, newCertificate]);
    
    addNotification({
        text: `You have been awarded a new certificate: "${data.certificateName}"!`,
        type: 'announcement',
        linkTo: `/certificates/${newCertificate.id}`,
    });
  };

  const value = { 
    loading, error,
    courses, bookRequests, tutorMessages, adminInstructions, studentProfiles, 
    adminProfile, tutorProfile, hackathons, hackathonRegistrations, tasks,
    notifications,
    leaderboardData,
    certificates,
    certificateTemplates,
    initializeDatabase, clearDatabase, getCourseById, getHackathonById, getStudentProfileById, addStudentProfile, addCourse, 
    deleteCourse, addCourseMaterial, addBookRequest, acceptBookRequest, 
    sendTutorMessage, broadcastInstruction, updateStudentProfile,
    updateAdminProfile, updateTutorProfile, createHackathon, updateHackathon,
    deleteHackathon, addHackathonAnnouncement, publishHackathonResults,
    registerForHackathon, getRegistrationForStudent,
    addTask, updateTask, deleteTask,
    markNotificationAsRead, markAllNotificationsAsRead, deleteNotification,
    getCertificateById,
    addCertificateTemplate,
    updateCertificateTemplate,
    deleteCertificateTemplate,
    issueCertificate,
    provideCertificate
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
