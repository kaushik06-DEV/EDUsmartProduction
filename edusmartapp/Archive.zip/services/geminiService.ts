// services/apiService.ts

const BASE_URL = 'http://localhost:3001/api'; 
/**
 * Retrieves the authentication token from localStorage.
 * @returns The token string or null if not found.
 */
const getToken = (): string | null => {
  try {
    return localStorage.getItem('authToken');
  } catch (error) {
    console.error("Could not read token from localStorage", error);
    return null;
  }
};

/**
 * A generic function to handle all API requests.
 * It sets the appropriate headers, includes the auth token, and handles responses.
 * @param endpoint The API endpoint to call (e.g., '/courses').
 * @param method The HTTP method ('GET', 'POST', 'PUT', 'DELETE').
 * @param body The request payload for POST/PUT requests.
 * @param signal An AbortSignal to allow for request cancellation.
 * @returns A promise that resolves with the JSON response.
 */
const apiService = async <T>(
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  body?: any,
  signal?: AbortSignal
): Promise<T> => {
  const token = getToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config: RequestInit = {
    method,
    headers,
    signal,
  };

  if (body) {
    config.body = JSON.stringify(body);
  }

  // In a real app, you would replace this with the actual base URL of your backend.
  const response = await fetch(`${BASE_URL}${endpoint}`, config);

  if (!response.ok) {
    // Try to parse the error response from the API, otherwise throw a generic error.
    const errorData = await response.json().catch(() => ({ message: 'An unknown API error occurred.' }));
    throw new Error(errorData.message || 'API request failed');
  }

  // For DELETE requests, the server might return a 204 No Content response.
  if (response.status === 204) {
      return null as T;
  }

  return response.json();
};

// Export a simplified interface for making API calls throughout the app.
export const api = {
  get: <T>(endpoint: string, signal?: AbortSignal) => apiService<T>(endpoint, 'GET', undefined, signal),
  post: <T>(endpoint: string, body: any, signal?: AbortSignal) => apiService<T>(endpoint, 'POST', body, signal),
  put: <T>(endpoint: string, body: any, signal?: AbortSignal) => apiService<T>(endpoint, 'PUT', body, signal),
  del: <T>(endpoint: string, signal?: AbortSignal) => apiService<T>(endpoint, 'DELETE', undefined, signal),
};