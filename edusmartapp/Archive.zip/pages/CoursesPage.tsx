import React, { useState, useMemo } from 'react';
import { PROGRAMS } from '../constants';
import CourseCard from '../components/CourseCard';
import { ProgramId } from '../types';
import Icon from '../components/Icon';
import { useData } from '../contexts/DataContext';
import { useLanguage } from '../i18n/index';

const CoursesPage: React.FC = () => {
    const { courses } = useData();
    const { t } = useLanguage();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedPrograms, setSelectedPrograms] = useState<Set<ProgramId>>(new Set());
    const [industryRelevance, setIndustryRelevance] = useState(0);
    const [selectedLevels, setSelectedLevels] = useState<Set<number>>(new Set());

    const handleProgramToggle = (programId: ProgramId) => {
        setSelectedPrograms(prev => {
            const newSet = new Set(prev);
            if (newSet.has(programId)) {
                newSet.delete(programId);
            } else {
                newSet.add(programId);
            }
            return newSet;
        });
    };
    
    const handleLevelToggle = (level: number) => {
        setSelectedLevels(prev => {
            const newSet = new Set(prev);
            if (newSet.has(level)) {
                newSet.delete(level);
            } else {
                newSet.add(level);
            }
            return newSet;
        });
    };

    const clearAllFilters = () => {
        setSearchTerm('');
        setSelectedPrograms(new Set());
        setIndustryRelevance(0);
        setSelectedLevels(new Set());
    };

    const filteredCourses = useMemo(() => {
        return courses.filter(course => {
            const matchesProgram = selectedPrograms.size === 0 || selectedPrograms.has(course.programId);
            const matchesSearch = course.name.toLowerCase().includes(searchTerm.toLowerCase()) || course.code.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesRelevance = course.industryRelevance >= industryRelevance;
            const matchesLevel = selectedLevels.size === 0 || selectedLevels.has(course.level);
            return matchesProgram && matchesSearch && matchesRelevance && matchesLevel;
        });
    }, [searchTerm, selectedPrograms, courses, industryRelevance, selectedLevels]);
    
    const hasActiveFilters = selectedPrograms.size > 0 || industryRelevance > 0 || selectedLevels.size > 0;


    return (
        <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="relative max-w-2xl mx-auto">
                <input
                    type="text"
                    placeholder={t('searchForCourses')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full p-4 pl-12 bg-white border-2 border-ui-border rounded-full shadow-apple text-ui-text-primary placeholder-ui-text-secondary focus:ring-2 focus:ring-ui-primary/20 focus:border-ui-primary focus:outline-none transition"
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                    <Icon name="search" className="w-6 h-6 text-ui-text-secondary" />
                </div>
            </div>
            
            <div>
                <h3 className="text-md font-semibold text-ui-text-secondary mb-3 text-center">{t('filterByProgram')}</h3>
                <div className="flex flex-wrap gap-3 justify-center">
                    {PROGRAMS.map(program => (
                        <button
                            key={program.id}
                            onClick={() => handleProgramToggle(program.id)}
                            className={`px-5 py-2 text-md font-semibold rounded-full transition-all duration-200 border-2 ${
                                selectedPrograms.has(program.id)
                                ? `${program.color} text-white border-transparent shadow-md`
                                : 'bg-ui-card text-ui-text-primary border-ui-border hover:bg-ui-hover hover:border-transparent'
                            }`}
                        >
                            {program.shortName}
                        </button>
                    ))}
                </div>
            </div>

            <div className="bg-ui-card rounded-2xl shadow-apple p-6 space-y-6">
                <h3 className="text-lg font-semibold text-ui-text-primary">{t('advancedFilters')}</h3>
                <div className="space-y-6 pt-6 border-t border-ui-border">
                    {/* Industry Relevance Filter */}
                    <div>
                        <label htmlFor="industryRelevance" className="block text-md font-medium text-ui-text-secondary">{t('industryRelevance')}: <span className="font-bold text-ui-text-primary">{industryRelevance}%+</span></label>
                        <input
                            id="industryRelevance"
                            type="range"
                            min="0"
                            max="100"
                            step="5"
                            value={industryRelevance}
                            onChange={(e) => setIndustryRelevance(Number(e.target.value))}
                            className="w-full h-2 bg-ui-background rounded-lg appearance-none cursor-pointer mt-2"
                        />
                    </div>
                    
                    {/* Course Level Filter */}
                    <div>
                        <h4 className="text-md font-medium text-ui-text-secondary mb-3">{t('courseLevel')}</h4>
                        <div className="flex flex-wrap gap-3">
                            {[1, 2, 3].map(level => (
                                <button
                                    key={level}
                                    onClick={() => handleLevelToggle(level)}
                                    className={`px-5 py-2 text-md font-semibold rounded-full transition-all duration-200 border-2 ${
                                        selectedLevels.has(level)
                                        ? 'bg-ui-primary text-white border-transparent shadow-md'
                                        : 'bg-ui-card text-ui-text-primary border-ui-border hover:bg-ui-hover hover:border-transparent'
                                    }`}
                                >
                                    {t('yearLevel', { level })}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
                 {hasActiveFilters && (
                    <div className="pt-6 border-t border-ui-border">
                        <button
                            onClick={clearAllFilters}
                            className="w-full sm:w-auto px-6 py-2 bg-ui-hover text-ui-text-primary font-semibold rounded-lg hover:bg-ui-border transition-colors"
                        >
                            {t('clearAllFilters')}
                        </button>
                    </div>
                 )}
            </div>

            <div>
                <p className="text-md text-ui-text-secondary mb-6">{t('showingCourses', { count: filteredCourses.length, total: courses.length })}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredCourses.map(course => (
                        <CourseCard key={course.id} course={course} />
                    ))}
                </div>
                 {filteredCourses.length === 0 && (
                    <div className="text-center py-16 text-ui-text-secondary col-span-full bg-ui-card rounded-2xl shadow-apple">
                        <p className="text-xl font-semibold">{t('noCoursesFound')}</p>
                        <p className="text-lg">{courses.length > 0 ? t('adjustFilters') : t('adminNeedsToImportData')}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CoursesPage;