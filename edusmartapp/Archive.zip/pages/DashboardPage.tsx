
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Icon from '../components/Icon';
import { useLanguage } from '../i18n/index';
import { useData } from '../contexts/DataContext';

const DashboardPage: React.FC = () => {
    const { t } = useLanguage();
    const { leaderboardData } = useData();

    const getRankIndicator = (rank: number) => {
        if (rank === 1) return <span className="text-2xl" role="img" aria-label="gold medal">🥇</span>;
        if (rank === 2) return <span className="text-2xl" role="img" aria-label="silver medal">🥈</span>;
        if (rank === 3) return <span className="text-2xl" role="img" aria-label="bronze medal">🥉</span>;
        return <span className="font-bold text-lg text-ui-text-secondary">{rank}</span>;
    };

    return (
        <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-ui-text-primary tracking-tight mb-8">{t('yourLearningDashboard')}</h2>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Content Column */}
                <div className="lg:col-span-2 space-y-8">
                    {/* Stat Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="bg-ui-card p-6 rounded-2xl shadow-apple flex items-center">
                            <div className="bg-ui-blue/10 text-ui-blue p-3 rounded-xl">
                                <Icon name="courses" className="w-6 h-6" />
                            </div>
                            <div className="ml-4">
                                <p className="text-ui-text-secondary text-md">{t('coursesExplored')}</p>
                                <p className="text-3xl font-bold text-ui-text-primary">5</p>
                            </div>
                        </div>
                        <div className="bg-ui-card p-6 rounded-2xl shadow-apple flex items-center">
                            <div className="bg-ui-yellow/10 text-ui-yellow p-3 rounded-xl">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            </div>
                            <div className="ml-4">
                                <p className="text-ui-text-secondary text-md">{t('todaysStudyTime')}</p>
                                <p className="text-3xl font-bold text-ui-text-primary">1h 45m</p>
                            </div>
                        </div>
                        <div className="bg-ui-card p-6 rounded-2xl shadow-apple flex items-center">
                            <div className="bg-ui-green/10 text-ui-green p-3 rounded-xl">
                                <Icon name="ai" className="w-6 h-6" />
                            </div>
                            <div className="ml-4">
                                <p className="text-ui-text-secondary text-md">{t('aiAssistanceToday')}</p>
                                <p className="text-3xl font-bold text-ui-text-primary">25m</p>
                            </div>
                        </div>
                    </div>

                    {/* Chart */}
                    <div className="bg-ui-card p-6 sm:p-8 rounded-2xl shadow-apple">
                        <h3 className="text-xl font-bold text-ui-text-primary mb-6 tracking-tight">{t('weeklyStudyHours')}</h3>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart
                                data={studyData}
                                margin={{ top: 5, right: 20, left: -15, bottom: 5 }}
                            >
                                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5EA" />
                                <XAxis dataKey="name" stroke="#8A8A8E" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="#8A8A8E" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip wrapperClassName="!bg-ui-card/80 !backdrop-blur-sm !border-ui-border !rounded-xl !shadow-apple" />
                                <Legend wrapperStyle={{fontSize: "14px"}}/>
                                <Bar dataKey="hours" fill="#007AFF" name={t('studyHours')} radius={[8, 8, 0, 0]} barSize={30} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Sidebar Column */}
                <div className="lg:col-span-1 space-y-8">
                    <div className="bg-ui-card p-6 rounded-2xl shadow-apple">
                        <h3 className="text-xl font-bold text-ui-text-primary mb-4 tracking-tight">{t('achievements')}</h3>
                        <div className="space-y-4">
                            <div className="flex items-center">
                                <span className="text-3xl">🔥</span>
                                <div className="ml-4">
                                    <p className="font-semibold text-ui-text-primary">5-Day Study Streak</p>
                                    <p className="text-md text-ui-text-secondary">Keep it up!</p>
                                </div>
                            </div>
                            <div className="flex items-center">
                                <span className="text-3xl">🧠</span>
                                <div className="ml-4">
                                    <p className="font-semibold text-ui-text-primary">AI Enthusiast</p>
                                    <p className="text-md text-ui-text-secondary">Asked 10+ AI questions</p>
                                </div>
                            </div>
                            <div className="flex items-center">
                                <span className="text-3xl">📚</span>
                                <div className="ml-4">
                                    <p className="font-semibold text-ui-text-primary">Course Explorer</p>
                                    <p className="text-md text-ui-text-secondary">Viewed 5 different courses</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-ui-card p-6 rounded-2xl shadow-apple">
                        <h3 className="text-xl font-bold text-ui-text-primary mb-4 tracking-tight">{t('leaderboard')}</h3>
                        <div className="space-y-3">
                            {leaderboardData.slice(0, 5).map((entry) => (
                                <div key={entry.studentId} className="flex items-center p-3 bg-ui-hover rounded-xl">
                                    <div className="w-8 text-center mr-3">
                                        {getRankIndicator(entry.rank)}
                                    </div>
                                    <div className="flex-1">
                                        <p className="font-semibold text-ui-text-primary truncate">{entry.studentName}</p>
                                        <p className="text-sm text-ui-text-secondary">{entry.points} {t('points')}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-ui-card p-6 rounded-2xl shadow-apple">
                        <h3 className="text-xl font-bold text-ui-text-primary mb-4 tracking-tight">{t('recommendations')}</h3>
                        <ul className="space-y-3 list-disc list-inside text-ui-primary">
                            <li><span className="text-ui-text-primary">{t('recommendation1')}</span></li>
                            <li><span className="text-ui-text-primary">{t('recommendation2')}</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

const studyData = [
  { name: 'Mon', hours: 2 },
  { name: 'Tue', hours: 3 },
  { name: 'Wed', hours: 1.5 },
  { name: 'Thu', hours: 4 },
  { name: 'Fri', hours: 2.5 },
  { name: 'Sat', hours: 5 },
  { name: 'Sun', hours: 1 },
];

export default DashboardPage;