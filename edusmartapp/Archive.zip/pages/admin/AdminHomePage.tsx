
import React, { useState } from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../i18n';
import Icon from '../../components/Icon';
import { Link } from 'react-router-dom';

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-ui-card p-6 rounded-2xl shadow-apple flex items-center space-x-4">
        <div className="bg-ui-hover p-4 rounded-xl">
            {icon}
        </div>
        <div>
            <p className="text-md text-ui-text-secondary">{title}</p>
            <p className="text-3xl font-bold text-ui-text-primary">{value}</p>
        </div>
    </div>
);

const AdminHomePage: React.FC = () => {
    const { studentProfiles, courses, tutorMessages, broadcastInstruction } = useData();
    const { studentLoginCount, tutorLoginCount } = useAuth();
    const { t } = useLanguage();
    const [instruction, setInstruction] = useState('');

    const handleBroadcast = (e: React.FormEvent) => {
        e.preventDefault();
        if (!instruction.trim()) return;
        broadcastInstruction(instruction);
        setInstruction('');
        alert(t('instructionBroadcasted'));
    };
    
    return (
        <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="text-center">
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-ui-text-primary tracking-tight">
                    {t('adminDashboardTitle')}
                </h2>
                <p className="text-ui-text-secondary mt-2 text-lg">{t('systemOverview')}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title={t('totalStudents')} value={studentProfiles.length} icon={<Icon name="students" className="w-7 h-7 text-accent-blue" />} />
                <StatCard title={t('totalCourses')} value={courses.length} icon={<Icon name="courses" className="w-7 h-7 text-accent-purple" />} />
                <StatCard title={t('studentLogins')} value={studentLoginCount} icon={<Icon name="profile" className="w-7 h-7 text-accent-green" />} />
                <StatCard title={t('tutorLogins')} value={tutorLoginCount} icon={<Icon name="tutor" className="w-7 h-7 text-accent-yellow" />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-ui-card p-8 rounded-2xl shadow-apple">
                    <h3 className="text-2xl font-bold text-ui-text-primary mb-4 tracking-tight">{t('broadcastAnnouncement')}</h3>
                    <form onSubmit={handleBroadcast} className="space-y-4">
                        <textarea
                            value={instruction}
                            onChange={(e) => setInstruction(e.target.value)}
                            placeholder={t('broadcastPlaceholder')}
                            className="w-full p-3 h-28 bg-ui-background border-2 border-ui-border rounded-xl text-ui-text-primary placeholder-ui-text-secondary focus:outline-none focus:ring-2 focus:ring-ui-primary/20 focus:border-ui-primary transition"
                            required
                        />
                        <button type="submit" className="w-full bg-ui-primary text-white font-bold py-3 px-6 rounded-xl hover:bg-opacity-80 transition-colors">
                            {t('broadcast')}
                        </button>
                    </form>
                </div>
                <div className="bg-ui-card p-8 rounded-2xl shadow-apple">
                    <h3 className="text-2xl font-bold text-ui-text-primary mb-4 tracking-tight">{t('recentTutorMessages')}</h3>
                    {tutorMessages.length > 0 ? (
                        <div className="space-y-3 max-h-72 overflow-y-auto">
                            {[...tutorMessages].reverse().map(msg => (
                                <div key={msg.id} className="p-4 bg-ui-hover rounded-xl">
                                    <p className="text-ui-text-primary">{msg.text}</p>
                                    <p className="text-xs text-ui-text-secondary mt-2 text-right">{new Date(msg.timestamp).toLocaleString()}</p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-ui-text-secondary text-center py-10">{t('noTutorMessages')}</p>
                    )}
                </div>
            </div>
             <div className="bg-ui-card p-6 rounded-2xl shadow-apple">
                <h3 className="text-2xl font-bold text-ui-text-primary mb-4 tracking-tight">{t('quickActions')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    <Link to="/admin" className="text-center p-4 bg-ui-hover rounded-xl hover:bg-ui-border transition-colors">
                        <Icon name="admin" className="w-8 h-8 mx-auto text-ui-primary" />
                        <p className="mt-2 font-semibold text-ui-text-primary">{t('adminPanel')}</p>
                    </Link>
                    <Link to="/courses" className="text-center p-4 bg-ui-hover rounded-xl hover:bg-ui-border transition-colors">
                        <Icon name="courses" className="w-8 h-8 mx-auto text-ui-primary" />
                        <p className="mt-2 font-semibold text-ui-text-primary">{t('courseManagement')}</p>
                    </Link>
                    <Link to="/admin/certificates" className="text-center p-4 bg-ui-hover rounded-xl hover:bg-ui-border transition-colors">
                        <Icon name="certificate" className="w-8 h-8 mx-auto text-ui-primary" />
                        <p className="mt-2 font-semibold text-ui-text-primary">{t('certificateManagement')}</p>
                    </Link>
                     <Link to="/profile" className="text-center p-4 bg-ui-hover rounded-xl hover:bg-ui-border transition-colors">
                        <Icon name="profile" className="w-8 h-8 mx-auto text-ui-primary" />
                        <p className="mt-2 font-semibold text-ui-text-primary">{t('profile')}</p>
                    </Link>
                </div>
             </div>
        </div>
    );
};

export default AdminHomePage;
